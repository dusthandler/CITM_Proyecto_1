In each folder of each element you have a readme in which are written the SFX that should include. 
Feel free to add in each readme the SFX you think is missing.
