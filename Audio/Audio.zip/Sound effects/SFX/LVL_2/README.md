SFX of lvl 2
