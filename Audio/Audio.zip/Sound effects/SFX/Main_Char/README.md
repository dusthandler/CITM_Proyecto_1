Sounds of the main char.

Includes 
-Shooting 
-Dying
-Reviving
(add whatever you find)
